package com.udacity.shoestore.screens.detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.udacity.shoestore.ActivityViewModel
import com.udacity.shoestore.R
import com.udacity.shoestore.databinding.FragmentDetailBinding
import com.udacity.shoestore.models.Shoe


/**
 * Fragment used to add a new shoe to the list.
 */
class DetailFragment : Fragment() {
    
    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val binding: FragmentDetailBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_detail, container, false)
        
        // init the view model as activity level
       val viewModel = ViewModelProvider(activity!!).get(ActivityViewModel::class.java)
        
        binding.lifecycleOwner = activity
        
        //Init data biding variables
        binding.viewModel = viewModel
        binding.shoe = Shoe("", 0.0, "", "")
        
        // Observer to navigate back to detail list
        viewModel.navigateToWelcome.observe(viewLifecycleOwner, Observer { navigate ->
            if (navigate) {
                findNavController().navigate(DetailFragmentDirections.actionDetailFragmentToShoesFragment())
                viewModel.navigationDone()
            }
        })
        return binding.root
    }
}