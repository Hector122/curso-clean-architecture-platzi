package com.udacity.shoestore

import android.content.Context
import android.graphics.Typeface
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.udacity.shoestore.models.Shoe


class ActivityViewModel : ViewModel() {
    private val _navigateToDetail = MutableLiveData<Boolean>()
    val navigateToWelcome: LiveData<Boolean> get() = _navigateToDetail
    
    private var _listOfShoes = MutableLiveData<MutableList<Shoe>>()
    val listOfShoes: LiveData<MutableList<Shoe>> get() = _listOfShoes
    
    init {
        setInitialListOfShoes()
    }
    
    fun onCancel() {
        _navigateToDetail.value = true
    }
    
    fun navigationDone() {
        _navigateToDetail.value = false
    }
    
    fun addShoe(shoe: Shoe) {
        _listOfShoes.value?.add(0, shoe)
        _navigateToDetail.value = true
        
        navigationDone()
    }
    
    fun addView(shoe: Shoe, context: Context, container: LinearLayout) {
        //Set the margins params
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(24, 20, 24, 52)
        
        // create the layout.
        val layout = LinearLayout(context)
        layout.layoutParams = params
        layout.orientation = LinearLayout.VERTICAL
        
        
        //Text view name
        val textName = TextView(context)
        textName.text = shoe.name
        textName.textSize = 24.0f
        setCommonParams(textName, context)
        
        //Text view company
        val textCompany = TextView(context)
        textCompany.text = context.resources.getString(
            R.string.company_and_size, shoe.company, shoe.size.toString()
        )
        textCompany.textSize = 16.0f
        setCommonParams(textCompany, context)
        
        
        //Text view description
        val textDescription = TextView(context)
        textDescription.text = shoe.description
        textDescription.textSize = 16.0f
        setCommonParams(textDescription, context)
        
        //Adding the TextViews to LinearLayout
        layout.addView(textName)
        layout.addView(textCompany)
        layout.addView(textDescription)
        
        container.addView(layout)
        
        //parentLayout.setBackgroundColor(Color.parseColor("#efdcf5"))
    }
    
    
    private fun setCommonParams(textView: TextView, context: Context) {
        // get a typeface for the font
        val typeface: Typeface? = ResourcesCompat.getFont(context, R.font.alice)
        
        val textViewParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        textViewParams.setMargins(16, 16, 16, 8)
        
        textView.layoutParams = textViewParams
        textView.typeface = typeface
    }
    
    /**
     * populate the list with the initial data.
     */
    private fun setInitialListOfShoes() {
        _listOfShoes.value = mutableListOf(
            Shoe(
                "Travis Scott x Jordan 1 Jordan",
                10.0,
                "Nike",
                "The Air Jordan series by Jordan Brand is considered the greatest signature shoe collection ever. The Air Jordan Retro line is at the forefront of modern sneaker collecting culture."
            ), Shoe(
                "Forum 84 ADV low sneaker",
                6.5,
                "Reebok ",
                "Reebok Women's Club C 85 Vintage Running Shoes brings pure essence with clean lines and a classic lineage. A Union Jack symbol along the side profile calls up heritage style."
            ), Shoe(
                "Levi's 990v3 sneaker",
                7.5,
                "New Balance",
                "A sneaker near-destined to appeal to a very particular group of enthusiasts. The real surprise, then, might be how widely adored New Balance's team-up with Levi's has become since its release in September."
            ), Shoe(
                "A Ma Maniére Retro 3 sneaker",
                11.0,
                "Jordan",
                "The Atlanta-based shop run by James Whitner remixed the Jordan 3, already one of the best silhouettes in the brand's arsenal, by adding luxe tumbled leather, key hits of suede, and retro-inspired yellowed midsoles"
            ), Shoe(
                "Adidas Samba sneaker",
                9.5,
                "Adidas",
                "Each season, the designer's tracksuits remain a standout, offering up throughtful meditiations on the nature of modern masculinity."
            )
        )
    }
}