package com.udacity.shoestore.screens.shoes

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.NavigationUI
import com.udacity.shoestore.ActivityViewModel
import com.udacity.shoestore.R
import com.udacity.shoestore.databinding.FragmentShoesBinding
import com.udacity.shoestore.models.Shoe
import com.udacity.shoestore.screens.detail.DetailFragmentDirections


/**
 * A simple [Fragment] subclass.
 * Use the [ShoesFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ShoesFragment : Fragment() {
    
    lateinit var viewModel: ActivityViewModel
    
    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val binding: FragmentShoesBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_shoes, container, false)
        
        // get view model with the activity as param
        viewModel = activity!!.let { ViewModelProvider(it).get(ActivityViewModel::class.java) }
        
        viewModel.listOfShoes.observe(viewLifecycleOwner, Observer { listOfShoes ->
            // set the list of shoes.
            for (item in listOfShoes.withIndex()) {
                viewModel.addView(item.value, this.context!!, binding.container)
            }
        })
        
        binding.floatingButton.setOnClickListener {
            findNavController().navigate(ShoesFragmentDirections.actionShoesFragmentToDetailFragment())
        }
        
        setHasOptionsMenu(true)
        
        return binding.root
    }
    
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.menu_main, menu)
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // when (item.itemId) { R.id.loginFragment -> } return super.onOptionsItemSelected(item)
        return NavigationUI.onNavDestinationSelected(
            item, view!!.findNavController()
        ) || super.onOptionsItemSelected(item)
    }
}