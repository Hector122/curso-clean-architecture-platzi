package com.udacity.shoestore

import android.os.Bundle
import android.view.Menu
import android.view.*
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.setupWithNavController
import com.udacity.shoestore.databinding.ActivityMainBinding
import com.udacity.shoestore.screens.detail.DetailFragmentDirections
import timber.log.Timber

class MainActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        //biding view
        val binding: ActivityMainBinding =
            DataBindingUtil.setContentView(this, R.layout.activity_main)
        
        // setup the nav controller with the toolbar and an AppBarConfiguration
        val navController = this.findNavController(R.id.nav_host_fragment)
        val appBarConfiguration = AppBarConfiguration(navController.graph)
        
        binding.toolbar.setupWithNavController(navController, appBarConfiguration)
        
        setSupportActionBar(binding.toolbar)
        
        //Support back arrow action.
        NavigationUI.setupWithNavController(binding.toolbar, navController)
        
        Timber.plant(Timber.DebugTree())
    }
}
