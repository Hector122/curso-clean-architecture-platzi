package com.openwebinars.filmapp

import android.app.Application

class FilmApp : Application() {

    override fun onCreate() {
        super.onCreate()
    }

}